 'use strict';

angular.module('CCS-Safety')
  .controller('UserCtrl', ['$scope', '$location', 'Api', 'Sharedata', 
    function ($scope, $location, Api, Sharedata) {
      Sharedata.clear();
      
     
  }]);